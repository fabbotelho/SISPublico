package com.boavistainfo.bvsis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BvsisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BvsisApplication.class, args);
	}

}
