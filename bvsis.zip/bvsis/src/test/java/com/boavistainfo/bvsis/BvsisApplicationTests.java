package com.boavistainfo.bvsis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BvsisApplicationTests {

	@Test
	void contextLoads() {
	}

}
